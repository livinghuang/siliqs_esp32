#pragma once
#include "siliqs_esp32.h"
#include "sq_ota.h"
#include "src.h"
void simulate_raw_init();
void simulate_raw_loop();